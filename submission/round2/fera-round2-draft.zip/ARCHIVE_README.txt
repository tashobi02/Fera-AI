Round 2 DRAFT PREPARATION; not uploaded or submitted.
Deck, PDF and actual local synthetic demo are at the archive root.
Repository README links/build commands refer to the full source checkout;
the separate storyboard and capture/build sources are available there.
The demo is typed, captioned, [MOCK] officer verification, timing edited.
Referral recorded (simulation). Release quality is not measured.
Drive, organiser instructions, private repository access, production and
human acceptance remain unresolved. selection-email-draft.md is not sent.
